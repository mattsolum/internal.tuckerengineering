<tr>
	<td>
		<?=$date?>
	</td>
	<?PHP if $type !== '':?>
	<td>
		<?=$type>
	</td>
	<?PHP endif; ?>
	<td>
		<?=$message?>
	</td>
	<td>
		<?=$source?>
	</td>
</tr>