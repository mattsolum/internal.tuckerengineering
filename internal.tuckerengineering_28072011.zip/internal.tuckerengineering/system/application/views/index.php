<?PHP $this->load->view('sections/header'); ?>
		Hello world!		
<?PHP $this->load->view('sections/footer'); ?>