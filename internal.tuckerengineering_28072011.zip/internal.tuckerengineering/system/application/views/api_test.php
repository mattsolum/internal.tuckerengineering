<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>

	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="description" content="Home structure and foundation inspections and reports." />
	<meta name="keywords" content="Home, Foundation, Structure, Inspection, Structural, Engineering, Report" />
	<meta name="author" content="Matthew Solum - http://www.matthewsolum.com" />
		
		<link rel="stylesheet" type="text/css" href="<?=BASE_URL?>resources/css/style.css" media="screen" />
		
	<title>TuckerEngineering.net</title>

</head>
	<body>
				<form method="POST" action="http://local/newTuckerEngineering/index.php/api/">
					<textarea></textarea>
				</form>
	</body>
</html>