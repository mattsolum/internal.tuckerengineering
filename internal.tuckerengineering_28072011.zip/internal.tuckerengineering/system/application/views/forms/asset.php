				<ul>
					<li>
						<label for="asset_filename">File name</label>
						<input type="text" name="asset_filename" id="asset_filename" />
					</li>
					<li>
						<label for="asset_type">Type</label>
						<input type="text" name="asset_type" id="asset_type" />
					</li>
					<li>
						<label for="asset_notes">Notes</label>
						<textarea id="asset_notes" name="asset_notes"></textarea>
					</li>
				</ul>