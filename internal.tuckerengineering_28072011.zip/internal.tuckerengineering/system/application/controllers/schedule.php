<?php

class Schedule extends Controller {

	function schedule()
	{
		parent::Controller();	
	}
	
	function index()
	{	
		$this->load->view('index');
	}
}

/* End of file schedule.php */
/* Location: ./system/application/controllers/schedule.php */