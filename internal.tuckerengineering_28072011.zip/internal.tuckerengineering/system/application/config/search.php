<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$search['per_page'] = 25;

$search['keyword_pre'] = '<span class="highlight">';
$search['keyword_post'] = '</span>';

$search['keyword_max_pre'] = 25;
$search['keyword_max_post'] = 25;

$search['description_len'] = 128;
