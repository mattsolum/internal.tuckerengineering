<?php defined('BASEPATH') OR exit('No direct script access allowed');

class REST
{
	private $request = '';
	private $request_format = 'xml';
		
	public function __construct()
	{
		
	}
	
	private function _user_auth($key)
	{
		
	}
	
	private function _format_output(format = '')
	{
		
	}
}