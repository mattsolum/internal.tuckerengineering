<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'doesnt_exist' 	=> "XML file for constants doesn't exist: <strong>%s</strong>",
);
