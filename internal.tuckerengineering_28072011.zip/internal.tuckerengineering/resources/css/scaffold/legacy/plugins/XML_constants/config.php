<?php defined('SYSPATH') OR die('No direct access allowed.');

$config = array
(	
	# Where is the xml file located? By default, it's in the
	# CSS directory in a file called constants.xml
	'xml_path' => './constants.xml',
);