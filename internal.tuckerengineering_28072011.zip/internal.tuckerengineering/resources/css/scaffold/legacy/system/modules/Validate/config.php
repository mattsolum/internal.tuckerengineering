<?php defined('SYSPATH') OR die('No direct access allowed.');

$config = array
(	
	# The CSS level to check - css1, css2, css21, css3, svg, svgbasic, svgtiny, mobile, atsc-tv, tv or none
	'profile' => 'css3',

	# The warning level, no for no warnings, 0 for less warnings, 1or 2 for more warnings
	'warning' => 1
);