<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'cannot_parse' 	=> "Cannot parse expression: <strong>%s</strong>",
);
