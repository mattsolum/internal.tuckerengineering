<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'missing_option' 	=> "Missing @grid option: <strong>%s</strong>",
);
