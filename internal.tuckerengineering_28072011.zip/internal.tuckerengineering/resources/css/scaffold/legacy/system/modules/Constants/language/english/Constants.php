<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'missing_constants' 	=> "The following constants are used, but not defined: %s",
);
