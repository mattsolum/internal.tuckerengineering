<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'recursion' 	=> "Recursion is occurring in this mixin: <strong>%s</strong>",
	'missing_mixin'	=> "The following Mixin does not exist: <strong>%s</strong>",
	'missing_param'	=> "Mixin is missing a required parameter: <strong>%s</strong>",
	'mixin_dir_error' => "The directory does not exist: <strong>%s</strong>"
);
