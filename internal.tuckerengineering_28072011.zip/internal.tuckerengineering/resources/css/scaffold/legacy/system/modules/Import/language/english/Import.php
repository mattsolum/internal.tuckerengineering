<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'recursion' 	=> "A file is being imported in a loop: <strong>%s</strong>",
	'not_css'		=> "The file you are trying to import isn't a CSS file: <strong>%s</strong>",
	'doesnt_exist'	=> "The included file doesn't exist: <strong>%s</strong>",
);
